package Exercise2;

public class RedRectangle extends Rectangle{
    public RedRectangle(int centerX, int centerY, int length, int width) {
        super(centerX, centerY, length, width);
        this.color = "red";
    }
}
