public abstract class Shape {
    Integer posX;
    Integer posY;

    public abstract void setSize(int x);

    public abstract double getArea();

    public abstract String info();

}